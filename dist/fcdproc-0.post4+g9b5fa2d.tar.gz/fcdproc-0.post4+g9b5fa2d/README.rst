===============================
JEM
===============================

.. image:: https://img.shields.io/travis/InatiLab/jem.svg
        :target: https://travis-ci.org/InatiLab/jem

.. image:: https://img.shields.io/pypi/v/jem.svg
        :target: https://pypi.python.org/pypi/jem


Python package for MRI and electrophysiology analysis.

* Free software: Public Domain
* Documentation: https://inatilab.github.io/jem.

Features
--------

* TODO

